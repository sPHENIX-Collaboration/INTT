var searchData=
[
  ['isbeamrun_70',['IsBeamRun',['../classDatabase.html#a9a13fb09a32aa3d6cb3cfbe8a853688a',1,'Database']]]
];
