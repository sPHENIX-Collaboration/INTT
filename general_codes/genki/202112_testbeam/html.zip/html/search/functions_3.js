var searchData=
[
  ['setrun_71',['SetRun',['../classDatabase.html#a900c8439b23b88c9e61a7fe476ae22cc',1,'Database::SetRun(string data)'],['../classDatabase.html#a199e3fdd062c857023a1864c38cea4a0',1,'Database::SetRun(int run_num)']]]
];
