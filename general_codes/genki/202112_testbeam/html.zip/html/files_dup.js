var files_dup =
[
    [ "Database.hh", "Database_8hh.html", [
      [ "Database", "classDatabase.html", "classDatabase" ],
      [ "Run", "classRun.html", "classRun" ]
    ] ],
    [ "database_demo.cc", "database__demo_8cc.html", "database__demo_8cc" ],
    [ "DrawPlots.cc", "DrawPlots_8cc_source.html", null ],
    [ "DrawPlots.hh", "DrawPlots_8hh_source.html", null ],
    [ "hit_num_bco_rejection.cc", "hit__num__bco__rejection_8cc_source.html", null ],
    [ "RemoveThisHit.cc", "RemoveThisHit_8cc_source.html", null ],
    [ "RemoveThisHit.hh", "RemoveThisHit_8hh_source.html", null ],
    [ "save_with_quality_cuts.cc", "save__with__quality__cuts_8cc_source.html", null ],
    [ "show_camac.cc", "show__camac_8cc_source.html", null ],
    [ "show_status.cc", "show__status_8cc_source.html", null ]
];