//extern G4double theoffset ;
class public_variable{
public:
  static G4double theoffset;
};
